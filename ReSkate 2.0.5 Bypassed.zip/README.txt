How to use:

1 - Replace all the files into your ReSkate folder.
2 - disable the auto update in ReSkate Launcher > Settings > Advanced > uncheck Install ReSkate updates.
3 - close the launcher and open again.
4 - click Play or Install