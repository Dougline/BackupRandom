# All Clothes

**All Clothes** for skate. (ReSkate): puts every clothing and cosmetic item that
is in the game's data but kept locked by ReSkate into your wardrobe.

## How to use

1. Install the mod with the ReSkate launcher, or copy the `allclothes` folder into
   `Skate\\Mods\\`, and make sure it is enabled.
2. Make sure ReSkate's **Unlock cosmetics** option is on (it is what marks
   modded items as owned).
3. Start the game. The extra items appear in their normal wardrobe tabs with an
   "All " prefix in their names and the "collector" rarity.

## How it works

ReSkate grants every cosmetic item except the ones that were paid or season-pass
items in the game's store catalogue; those it re-locks on every start. This mod
adds a copy of each locked item under a new key (`Own_All_...`) to the game's
item master collection. A copy uses the original's meshes, textures, thumbnail
and categories, so it looks and behaves exactly like the original; only its
name differs. The originals are left untouched, so anything you already own is
unaffected.

Which items are locked is read, at build time, from ReSkate's content-catalogue
cache, applying ReSkate's own rules (see `tools/reskate_catalog.py`).

## Contents

- board: 298
- board stickers: 260
- bottoms: 126
- eyewear: 36
- fullbodycostume: 17
- hats: 125
- outfit: 22
- shoes: 154
- socks: 27
- tattoo: 120
- tops: 297

## Compatibility

- Built for Skate build 25414733 (the build ReSkate supports).
- Adds items and extends the item master collection. Adds no code. ReSkate
  merges the collection edit with other cosmetic mods.
- Item titles are derived from keys (ReSkate has no localized names for modded
  items).

## Building from source

```
python tools/build_allclothes.py --game "<folder with Skate.exe>" --out .
python tools/make_release.py --mod . --out ../AllClothes-release
```

The tools folder is a Python port of ReSkate's Frostbite format code and
catalogue reader and is licensed under the GPL-3.0 (see `tools/LICENSE`).
